# Project Report — Supervised Learning: Fraud Detection Pipeline

## 1. Introduction
Fraud detection is a binary classification problem in which a machine-learning system attempts to distinguish legitimate transactions from fraudulent transactions.

The project brief requires handling a highly imbalanced dataset, applying SMOTE, training Logistic Regression and Random Forest models, tuning hyperparameters, and evaluating the models with Precision, Recall and ROC-AUC.

## 2. Dataset
The project uses the Credit Card Fraud Detection dataset supplied as `creditcard.csv`.

The target column is `Class`:
- `0` = normal transaction
- `1` = fraudulent transaction

The dataset is highly imbalanced, which makes ordinary Accuracy an unreliable primary metric.

## 3. Data Cleaning
The notebook checks:
- dataset dimensions
- data types
- missing values
- duplicate rows
- target distribution

Duplicate rows are removed and missing rows are dropped if present.

## 4. Exploratory Data Analysis
EDA includes:
- class-distribution visualization
- fraud percentage
- transaction amount distribution
- transaction amount boxplot

These steps show why imbalance must be handled carefully.

## 5. Train/Test Split
The data is divided into training and testing sets using an 80/20 split with stratification. Stratification preserves the rare fraud class in both sets.

## 6. SMOTE
SMOTE (Synthetic Minority Over-sampling Technique) creates synthetic minority-class observations.

SMOTE is applied only to the training portion through an `imblearn` pipeline. The test set is never oversampled.

## 7. Logistic Regression
Logistic Regression is trained after RobustScaler and SMOTE. Hyperparameter `C` is tuned with GridSearchCV using ROC-AUC scoring.

## 8. Random Forest
Random Forest is trained after SMOTE. The tuning grid includes the number of trees, maximum tree depth, and minimum samples required for splitting.

## 9. Evaluation Metrics
### Precision
Measures how many transactions predicted as fraud are actually fraud.

### Recall
Measures how many actual fraud transactions are detected.

### ROC-AUC
Measures the model's ability to distinguish fraudulent transactions from normal transactions across classification thresholds.

### Confusion Matrix
Shows:
- True Negatives
- False Positives
- False Negatives
- True Positives

## 10. Why Accuracy Is Not the Main Metric
With a highly imbalanced fraud dataset, a model can obtain high Accuracy by predicting the majority class most of the time while missing many fraud cases. Therefore this project uses Precision, Recall and ROC-AUC as the primary evaluation metrics.

## 11. Feature Importance
Random Forest feature importance is plotted to identify the input variables that contributed most to the model's decisions. The V1–V28 variables are anonymized, so their names should not be interpreted as direct business meanings.

## 12. Conclusion
The completed pipeline demonstrates the main supervised-learning requirements in the project brief: class-imbalance handling with SMOTE, two classification algorithms, hyperparameter tuning, and strict evaluation using Precision, Recall and ROC-AUC.

The final model should be discussed in terms of the trade-off between false positives and false negatives rather than Accuracy alone.
